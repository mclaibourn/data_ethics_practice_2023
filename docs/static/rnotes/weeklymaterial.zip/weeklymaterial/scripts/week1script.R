# Public Interest Data::Ethics & Practice
# Getting started with R: examine, summarize, dplyr I
# Packages: dplyr
# 2023-01-19
# Michele Claibourn


# ..................................................
# Notes ----
# Text with a "#" in front of it are comments.
# Keyboard shortcuts
#  To generate the assignment operator, <-, type Alt - (Win/Linux) or Option - (Mac) 
#  To submit a line of R code from a script, place the cursor in the line and hit Ctrl + Enter (Win/Linux) or Cmd + Return (Mac)
#  To submit many lines of R code from a script, highlight the lines and hit Ctrl + Enter (Win/Linux) or Cmd + Return (Mac).


# ..................................................
# Set up ----

# Load libraries
library(tidyverse)
library(janitor)

# Read data
# Recorded police stops by charlottesville jurisdiction (July 1, 2020-November 20, 2022)
# https://data.virginia.gov/stories/s/Virginia-Community-Policing-Act-Data-Collection/rden-cz3h/
stops <- read_csv("data/cville_police_stop.csv")


# ..................................................
# Examine data (base R) ----

# information about the data frame
names(stops)
head(stops)
tail(stops, 3)
str(stops)
glimpse(stops)

# summaries: 
# for numeric and integer - mean, 5-number sum, NA
# for factors -- frequencies
# for characters -- nothing
summary(stops)


# ..................................................
# Examine data (dplyr, isolating) ----

# clean up the names with janitor
stops <- clean_names(stops)

# count
# What are person types or reasons for stops? What are their frequencies
count(stops, person_type)
count(stops, reason_for_stop)


# select
# select/view the variables related to person type, race, and ethnicity
select(stops, person_type, race, ethnicity)


# filter
# Find all stop-n-frisk/terry stop cases
filter(stops, reason_for_stop == "TERRY STOP")
# Find all stops of people under 21
filter(stops, age < 21)


# ..................................................
# PIPES!!! ----
# Shortcut on Mac: cmd + shift + m
# Shortcut on Windows: ctrl + shift + m

# filter for terry stops of individuals under 21
#   and select variables related person characteristics

# Nested
select(
  filter(stops, age < 21 & reason_for_stop == "TERRY STOP"), 
  person_type, race, ethnicity
  )

# Intermediate steps
tmp <- filter(stops, age < 21 & reason_for_stop == "TERRY STOP")
tmp <- select(tmp, person_type, race, ethnicity)
tmp

# Pipes
stops %>% 
  filter(age < 21 & reason_for_stop == "TERRY STOP") %>% 
  select(person_type, race, ethnicity) 


# OR, filter for all terry tops and look at the frequency distribution of race
stops %>% 
  filter(reason_for_stop == "TERRY STOP") %>% 
  count(race)
