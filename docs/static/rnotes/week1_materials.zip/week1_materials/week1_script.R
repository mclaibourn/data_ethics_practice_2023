# Data Visualization in R
# 2022-08-30
# Getting Started in R


# ..................................................
# Notes ----
# Text with a "#" in front of it are called comments.
# Keyboard shortcuts
#  To generate the assignment operator, <-, type Alt - (Win/Linux) or Option - (Mac) 
#  To submit a line of R code from a script, place the cursor in the line and hit Ctrl + Enter (Win/Linux) or Cmd + Return (Mac)
#  To submit many lines of R code from a script, highlight the lines and hit Ctrl + Enter (Win/Linux) or Cmd + Return (Mac).


# ..................................................
# Load libraries ----
library(tidyverse)


# ..................................................
# Load and inspect data ----
# You can import pretty much any data into R: Excel, Stata, SPSS, SAS, 
# CSV, JSON, fixed-width, TXT, DAT, shape files, etc. 
property <- read_csv("data/parcels_cards_chacteristics.csv")

# multiple ways of looking at the ata
names(property)
glimpse(property)
head(property)
table(property$cardtype) # base R functions 
# In most  base R functions you need to refer to variables with $.
# The tidyverse uses "data-masking" so doesn't require the $


# ..................................................
# dplyr verbs, isolating ----
# count
# How many properties in each county voting district?
count(property, magisterialdistrict)

# How many properties are assigned each condition value?


# select
# Select the yearbuilt column
select(property, yearbuilt)

# Select the variables related to heating and cooling


# filter
# Find all properties built in 2022
filter(property, yearbuilt == 2022)

# Find all residential properties built in 2022


# arrange
# Sort properties by year built 
arrange(property, yearbuilt)
arrange(property, desc(yearbuilt))

# Sort properties by total value



# ..................................................
# pipes ----
# nesting functions
# filter for residential properties built in 2021 AND 
#   select total value and size AND
#   sort in descending order of value
arrange(
  select(
    filter(property, yearbuilt == 2021 & cardtype == "R"), 
    totalvalue, finsqft), 
  desc(totalvalue))

# saving intermediate steps
tmp <- filter(property, yearbuilt == 2021 & cardtype == "R")
tmp <- select(tmp, totalvalue, finsqft)
arrange(tmp, desc(totalvalue))

# using the pipe
property %>% 
  filter(yearbuilt == 2021 & cardtype == "R") %>% 
  select(totalvalue, finsqft) %>% 
  arrange(desc(totalvalue))


# ..................................................
# dplyr verbs, deriving ----
# summarize
# What is the size of the smallest residential property built in 2021?
# What is the size of the largest residential property built in 2021?
# How many properties were built in 2021
property %>% 
  filter(yearbuilt == 2021 & cardtype == "R") %>% 
  summarize(smallest = min(finsqft), 
            biggest = max(finsqft), 
            total = n())

# What's the most highly assessed residential property built in 2021?
# What's the least highly assessed residential property built in 2021?



# group_by
# What is the smallest and largest residential property in 2021 by magisterial district?
# How many residential properties were built in 2021 in each district?
# What is the average assessed value by district?
# Sort the districts by average value of 2021 properties.
property %>% 
  filter(yearbuilt == 2021 & cardtype == "R") %>% 
  group_by(magisterialdistrict) %>% 
  summarize(smallest = min(finsqft), 
            biggest = max(finsqft),
            number = n(),
            avg_value = mean(totalvalue, na.rm = TRUE)) %>% 
  arrange(desc(avg_value))

# mutate
# Let's calculate the value/square foot,
#   and then answer the question above again (adding the average value/sqft)
property %>% 
  filter(yearbuilt == 2021 & cardtype == "R") %>% 
  mutate(value_sqft = totalvalue/finsqft) %>% 
  group_by(magisterialdistrict) %>% 
  summarize(smallest = min(finsqft), 
            biggest = max(finsqft),
            number = n(),
            avg_value = mean(totalvalue, na.rm = TRUE),
            avg_value_sqft = mean(value_sqft)) %>% 
  arrange(desc(avg_value))

# Let's create a dataframe with the median sale price by the year of sale
#   (and number of sales) among residential properties.
# We need to filter for residential properties
#   and remove observations with sale prices of 0,
#   then group and summarize

property_sale_price <- property %>%
  filter(lastsaleprice > 0, cardtype == "R") %>%
  group_by(last_sale_year) %>%
  summarize(median_sale = median(lastsaleprice),
            num_sale = n())


# ..................................................
# ggplot2 ----
# scatterplot example
# Does the size of the house change as a function of the year built?
ggplot(property, aes(x = yearbuilt, y = finsqft)) +
  geom_point()

# filter for residential properties
# map magisterial district to the color aesthetic
# change shape or transparency of points for overplotting
property %>% filter(cardtype == "R") %>%
  ggplot(aes(x = yearbuilt, y = finsqft, color = magisterialdistrict)) +
  geom_point(alpha = 1/5)
  #geom_point(shape = ".")

# facet by magisterial district as well
property %>% filter(cardtype == "R") %>%
  ggplot(aes(x = yearbuilt, y = finsqft, color = magisterialdistrict)) +
  geom_point(shape = ".") +
  facet_wrap(~magisterialdistrict)

# try something different
property %>% filter(cardtype == "R") %>%
  ggplot(aes(x = yearbuilt, y = finsqft, color = magisterialdistrict)) +
  geom_count(alpha = 1/5)

# How about year built and lotsize or residential properties?



# line example
# How many residential properties were built each year?
property %>% 
  filter(cardtype == "R" & yearbuilt < 2022) %>% 
  group_by(year = yearbuilt) %>% 
  summarize(total = n()) %>% 

  ggplot(aes(x = year, y = total)) +
  geom_line()

# Use the property sale price year data frame we created earlier
#   to graph the average sale price by year of sale
#   (filter to 1983-2020)



# bar example
# How many residential properties in each magisterial district?
property %>% 
  filter(cardtype == "R") %>% 
  ggplot(aes(x = magisterialdistrict)) +
  geom_bar()

# order the district factors by frequency
# change the color of the bars
# create era as an ordered factor and add it as a fill aesthetic
property %>%
  filter(cardtype == "R"  & !is.na(magisterialdistrict) & !is.na(yearbuilt)) %>%
  mutate(era = case_when(
           yearbuilt < 1950 ~ "Pre-1950",
           yearbuilt >= 1950 & yearbuilt < 2000 ~ "1950-1999",
           yearbuilt >= 2000 ~ "Post-2000"),
         era = factor(era, levels = c("Pre-1950", "1950-1999", "Post-2000"))
         ) %>%
  select(yearbuilt, era, magisterialdistrict) %>%
  ggplot(aes(x = fct_infreq(magisterialdistrict), fill = era)) +
  geom_bar(position = "fill")

